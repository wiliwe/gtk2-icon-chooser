// gcc gtkSwapPixmaps.c -o gtkSwapPixmaps `pkg-config --cflags --libs gtk+-2.0`
#include <gtk/gtk.h>
#include <stdio.h>

static char *GreyBox[] = {
/* width height num_colors chars_per_pixel */
"    25    10        1            1",
/* colors */
". c #e6e6e6",
/* pixels */
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
"........................."
};
static char *RedBox[] = {
"    25    10        1            1",
". c #dd0000",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
"........................."
};
static char *GreenBox[] = {
"    25    10        1            1",
". c #00dd00",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
".........................",
"........................."
};

// Global variables
GtkWidget *redBox;
GtkWidget *greenBox;
GtkWidget *greyBox;

// Callback:  The data passed to this function is printed to stdout.
static void callback1( GtkWidget *widget,
                       gpointer   data )
{
    g_print ("Hello again - %s was pressed\n", (gchar *) data);

    gtk_widget_hide(greyBox);
    gtk_widget_hide(redBox);
    gtk_widget_show(greenBox);
}

static void callback2( GtkWidget *widget,
                       gpointer   data )
{
    g_print ("Hello again - %s was pressed\n", (gchar *) data);

    gtk_widget_hide(greyBox);
    gtk_widget_hide(greenBox);
    gtk_widget_show(redBox);
}

/* Callback to close window */
static gboolean delete_event( GtkWidget *widget,
                              GdkEvent  *event,
                              gpointer   data )
{
    g_print("delete_event\n");
    gtk_main_quit ();
    return FALSE;
}

int main( int   argc,
          char *argv[] )
{
    GtkWidget *window;
    GdkPixmap *_icon_red;
    GdkPixmap *_icon_green;
    GdkPixmap *_icon_grey;
    GdkBitmap *_icon_mask_red;
    GdkBitmap *_icon_mask_green;
    GdkBitmap *_icon_mask_grey;
    GtkStyle  *_style_red;
    GtkStyle  *_style_green;
    GtkStyle  *_style_grey;
    GtkWidget *button1;
    GtkWidget *button2;
    GtkWidget *hbox1;

    // This is called in all GTK applications. Arguments are parsed
    // from the command line and are returned to the application.
    gtk_init (&argc, &argv);

    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Click a Button!");

    // Here we just set a handler for delete_event that immediately exits GTK.
    g_signal_connect (G_OBJECT (window), "delete_event",
                      G_CALLBACK (delete_event), NULL);

    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_show (window);  // Pitfall!! Must put this here and NOT at end.

    hbox1 = gtk_hbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (window), hbox1);

    // ------------------------------------------------------------------------
    //                     Grey
    _style_grey = gtk_widget_get_style( window );
    _icon_grey = gdk_pixmap_create_from_xpm_d(GTK_WIDGET(window)->window,
                                        &_icon_mask_grey,
                                        &_style_grey->bg[GTK_STATE_NORMAL],
                                        GreyBox);
    greyBox = gtk_pixmap_new(_icon_grey, _icon_mask_grey);
    g_object_unref(_icon_grey);
    g_object_unref(_icon_mask_grey);
    gtk_widget_show(greyBox);

    //                     Green
    _style_green = gtk_widget_get_style( window );
    _icon_green = gdk_pixmap_create_from_xpm_d(GTK_WIDGET(window)->window,
                                        &_icon_mask_green,
                                        &_style_green->bg[GTK_STATE_NORMAL],
                                        GreenBox);
    greenBox = gtk_pixmap_new(_icon_green, _icon_mask_green);
    g_object_unref(_icon_green);
    g_object_unref(_icon_mask_green);

    //                     Red
    //m_redBox[ii] = gtk_image_new_from_file("redBox.xpm");
    _style_red = gtk_widget_get_style( window );
    _icon_red = gdk_pixmap_create_from_xpm_d(GTK_WIDGET(window)->window,
                                        &_icon_mask_red,
                                        &_style_red->bg[GTK_STATE_NORMAL],
                                        RedBox);
    redBox = gtk_pixmap_new(_icon_red, _icon_mask_red);
    g_object_unref(_icon_red);
    g_object_unref(_icon_mask_red);

    // ------------------------------------------------------------------------

    // Attach both images to the same place!!
    gtk_box_pack_start (GTK_BOX(hbox1), greyBox, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(hbox1), greenBox, TRUE, TRUE, 0);
    gtk_box_pack_start (GTK_BOX(hbox1), redBox, TRUE, TRUE, 0);


    // Position both images in the same location
    gtk_misc_set_alignment(GTK_MISC(greyBox), 1, 0.5);
    gtk_misc_set_alignment(GTK_MISC(greenBox), 1, 0.5);
    gtk_misc_set_alignment(GTK_MISC(redBox), 1, 0.5);

    // ------------------------------------------------------------------------

    button1 = gtk_button_new_with_label("  Green  ");
    g_signal_connect (G_OBJECT (button1), "clicked",
                      G_CALLBACK (callback1), (gpointer) "button1");
    gtk_box_pack_start(GTK_BOX(hbox1), button1, TRUE, TRUE, 0);
    gtk_widget_show (button1);

    // ------------------------------------------------------------------------

    button2 = gtk_button_new_with_label("   Red   ");
    g_signal_connect (G_OBJECT (button2), "clicked",
                      G_CALLBACK (callback2), (gpointer) "button2");
    gtk_box_pack_start(GTK_BOX(hbox1), button2, TRUE, TRUE, 0);
    gtk_widget_show (button2);

    // ------------------------------------------------------------------------

    gtk_widget_show(hbox1);

    // Rest in gtk_main and wait for user input.
    gtk_main ();

    return 0;
}

